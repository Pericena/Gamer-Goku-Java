package main;

import java.awt.image.BufferedImage;

import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;

import Enemigos.Chucho;
import Enemigos.EscupeFuego;
import Enemigos.Fantasma;
import Enemigos.Fuego;
import Enemigos.MonstruoFuego;
import Enemigos.Tortuga;
import Enemigos.TortugaSaltarina;



public class Personaje {
	
	java.net.URL url;
	BufferedImage spriteExplosion;
	BufferedImage spriteGoku;
	BufferedImage spriteEnemigosMario;


	
	public Personaje() throws IOException{
		url = this.getClass().getResource("explosion.png");
		spriteExplosion = ImageIO.read(url);
		url = this.getClass().getResource("goku2.png");
		spriteGoku = ImageIO.read(url);
		url = this.getClass().getResource("marioEnemigos.png");
		spriteEnemigosMario = ImageIO.read(url);


		

	}

	
		

	
	public EscupeFuego getEscupeFuego(){
		Animacion fuego = new Animacion(spriteEnemigosMario);
		fuego.agregarFrame(new FrameInfo(297,762,16,23), 200);
		fuego.agregarFrame(new FrameInfo(333,762,16,24), 300);
		fuego.agregarFrame(new FrameInfo(377,716,16,35), 100);
		fuego.agregarFrame(new FrameInfo(377,760,16,47), 100);
		fuego.agregarFrame(new FrameInfo(376,816,17,55), 100);
		
		ArrayList<Animacion> animaciones = new ArrayList<Animacion>();
		animaciones.add(fuego);
		EscupeFuego efuego = new EscupeFuego(animaciones);
		efuego.setEscala(2f, 2.5f);
		efuego.setIndiceAnimacion(0);
		return efuego;
	}
	
	public MonstruoFuego getMonstruoFuego(){
		Animacion quieto = new Animacion(spriteEnemigosMario);
		quieto.agregarFrame(new FrameInfo(417,1166,16,15), 50);
		quieto.agregarFrame(new FrameInfo(417,1166,16,15), 50);
		quieto.setNombre("quieto");
		
		Animacion ataque = new Animacion(spriteEnemigosMario);
		ataque.agregarFrame(new FrameInfo(351,1158,47,32), 50);
		ataque.agregarFrame(new FrameInfo(291,1158,47,32), 50);
		
		ArrayList<Animacion> animaciones = new ArrayList<Animacion>();
		animaciones.add(quieto);
		animaciones.add(ataque);
		MonstruoFuego fuego = new MonstruoFuego(animaciones);
		fuego.setEscala(2f, 1.5f);
		fuego.setIndiceAnimacion(0);
		return fuego;
		
	}
	
	public Fuego getFuego(){
		//Se prepara la fuego
		Animacion aFuego = new Animacion(spriteEnemigosMario);
		aFuego.agregarFrame(new FrameInfo(257,1006,16,16), 50);
		aFuego.agregarFrame(new FrameInfo(301,1002,47,24), 50);
		aFuego.agregarFrame(new FrameInfo(381,998,47,32), 50);
		aFuego.agregarFrame(new FrameInfo(5,1038,79,32), 50);
		aFuego.agregarFrame(new FrameInfo(95,1038,80,32), 50);
		aFuego.agregarFrame(new FrameInfo(275,1038,80,32), 50);
		aFuego.agregarFrame(new FrameInfo(365,1038,74,32), 50);
		aFuego.agregarFrame(new FrameInfo(5,1078,80,32), 50);
		aFuego.agregarFrame(new FrameInfo(75,1078,80,32), 50);
		aFuego.agregarFrame(new FrameInfo(185,1078,80,32), 50);
		aFuego.agregarFrame(new FrameInfo(365,1082,74,24), 50);
		aFuego.agregarFrame(new FrameInfo(5,1126,31,16), 50);
		aFuego.agregarFrame(new FrameInfo(53,1126,31,16), 50);
		aFuego.agregarFrame(new FrameInfo(95,1126,15,16), 50);
		
		ArrayList<Animacion> animaciones = new ArrayList<Animacion>();
		animaciones.add(aFuego);
		Fuego fuego = new Fuego(animaciones);
		fuego.setEscala(2f, 1.5f);
		return fuego;
	}
	

        
	public Chucho getChucho(){
		//Se prepara la explosion
		Animacion explosion = getExplosion();
		
		//Chucho camina a la izquierda
		Animacion caminaI = new Animacion(spriteEnemigosMario);		
		caminaI.agregarFrame(new FrameInfo(169,638,32,32), 50);
		caminaI.agregarFrame(new FrameInfo(129,638,32,31), 50);
		
		//Chucho camina a la derecha
		Animacion caminaD = new Animacion(spriteEnemigosMario);
		caminaD.agregarFrame(new FrameInfo(244,1986,32,32), 50);
		caminaD.agregarFrame(new FrameInfo(284,1986,32,31), 50);
		
		ArrayList<Animacion> animaciones = new ArrayList<Animacion>();
		animaciones.add(explosion);
		animaciones.add(caminaI);
		animaciones.add(caminaD);
		
		Chucho chucho = new Chucho(animaciones);
		chucho.setIndiceAnimacion(1);
		chucho.setEscalaX(2f);
		chucho.setEscalaY(2f);
		return chucho;		
		
	}
	
	public Fantasma getFantasma(){
		//Fantasma moviendose a la Izquierda
		Animacion moviendoseI = new Animacion(spriteEnemigosMario);
		moviendoseI.agregarFrame(new FrameInfo(371,1242,67,64), 50);
		
		//Fantasma moviendose a la izquierda tapado
		Animacion moviendoseItapado = new Animacion(spriteEnemigosMario);
		moviendoseItapado.agregarFrame(new FrameInfo(293,1242,64,64), 50);
		
		//Fantasma moviendose a la derecha
		Animacion moviendoseD = new Animacion(spriteEnemigosMario);
		moviendoseD.agregarFrame(new FrameInfo(7,2590,67,64), 50);
		
		//Fantasma moviendose a la derecha tapado
		Animacion moviendoseDtapado = new Animacion(spriteEnemigosMario);
		moviendoseDtapado.agregarFrame(new FrameInfo(88,2590,64,64), 50);
		
		ArrayList<Animacion> animaciones = new ArrayList<Animacion>();
		animaciones.add(moviendoseI);
		animaciones.add(moviendoseItapado);
		animaciones.add(moviendoseD);
		animaciones.add(moviendoseDtapado);
		
		Fantasma fantasma = new Fantasma(animaciones);
		fantasma.setIndiceAnimacion(1);
		//fantasma.setEscalaX(2f);
		//fantasma.setEscalaY(2f);
		return fantasma;
	}
	
	
	public TortugaSaltarina getTortugaVerdeSaltarina(){
		//Se prepara la explosion
		Animacion explosion = getExplosion();
		//Tortuga caminando a la izquierda
		Animacion saltandoI = new Animacion(spriteEnemigosMario);
		saltandoI.agregarFrame(new FrameInfo(136,40,17,27), 100);
		saltandoI.agregarFrame(new FrameInfo(94,40,22,28), 100);
		//Tortuga caminando a la derecha
		Animacion saltandoD = new Animacion(spriteEnemigosMario);
		saltandoD.agregarFrame(new FrameInfo(292,1388,17,27), 100);
		saltandoD.agregarFrame(new FrameInfo(329,1388,22,28), 100);
		
		ArrayList<Animacion> animaciones = new ArrayList<Animacion>();
		animaciones.add(explosion);
		animaciones.add(saltandoI);
		animaciones.add(saltandoD);
		
		TortugaSaltarina tortuga = new TortugaSaltarina(animaciones);
		tortuga.setIndiceAnimacion(1);
		tortuga.setEscalaX(2f);
		tortuga.setEscalaY(2f);
		return tortuga;
	}
	
	public Tortuga getTortugaRojaCaminado()throws IOException{
		//Se prepara la explosion
		Animacion explosion = getExplosion();
		//Tortuga caminando a la izquierda
		Animacion caminandoI = new Animacion(spriteEnemigosMario);
		caminandoI.agregarFrame(new FrameInfo(297,0,16,27), 100);
		caminandoI.agregarFrame(new FrameInfo(257,1,16,26), 100);
		//Tortuga caminando a la derecha
		Animacion caminandoD = new Animacion(spriteEnemigosMario);
		caminandoD.agregarFrame(new FrameInfo(132,1348,16,27), 100);
		caminandoD.agregarFrame(new FrameInfo(172,1349,16,27), 100);
		
		ArrayList<Animacion> animaciones = new ArrayList<Animacion>();
		animaciones.add(explosion);
		animaciones.add(caminandoI);
		animaciones.add(caminandoD);
		
		Tortuga tortuga = new Tortuga(animaciones);
		tortuga.setIndiceAnimacion(1);
		tortuga.setEscalaX(2f);
		tortuga.setEscalaY(2f);
		return tortuga;		
	}
	
	public Jugador getGoku() throws IOException{		
		
		//Se prepara la animacion EXPLOSION
		Animacion explosion = getExplosion();	
		
		//goku esta parado hacia la derecha
		Animacion paradoD = new Animacion(spriteGoku);
		paradoD.agregarFrame(new FrameInfo(12,10,26,37), 100);
		paradoD.agregarFrame(new FrameInfo(48,11,28,36), 100);
		paradoD.agregarFrame(new FrameInfo(85,9,28,38), 100);
		paradoD.agregarFrame(new FrameInfo(122,9,27,38), 100);
		paradoD.agregarFrame(new FrameInfo(159,10,27,37), 100);
		paradoD.agregarFrame(new FrameInfo(195,11,27,36), 100);
		
		//Goku esta parado hacia la izquierda
		Animacion paradoI = new Animacion(spriteGoku);
		paradoI.agregarFrame(new FrameInfo(491,750,26,37), 100);
		paradoI.agregarFrame(new FrameInfo(454,751,28,36), 100);
		paradoI.agregarFrame(new FrameInfo(417,749,28,38), 100);
		paradoI.agregarFrame(new FrameInfo(381,749,27,38), 100);
		paradoI.agregarFrame(new FrameInfo(344,750,27,37), 100);
		paradoI.agregarFrame(new FrameInfo(308,751,27,36), 100);
		
		//Goku esta caminando a la derecha
		Animacion caminandoD = new Animacion(spriteGoku);
		caminandoD.agregarFrame(new FrameInfo(8,298,28,38), 50);
		caminandoD.agregarFrame(new FrameInfo(45,300,27,37), 50);
		caminandoD.agregarFrame(new FrameInfo(80,296,28,40), 50);
		caminandoD.agregarFrame(new FrameInfo(119,297,27,38), 50);
		caminandoD.agregarFrame(new FrameInfo(155,296,28,37), 50);
		caminandoD.agregarFrame(new FrameInfo(194,295,27,37), 50);
		caminandoD.agregarFrame(new FrameInfo(230,293,27,40), 50);
		caminandoD.agregarFrame(new FrameInfo(268,294,27,38), 50);
		
		//Goku esta caminando a la izquierda
		Animacion caminandoI = new Animacion(spriteGoku);
		caminandoI.agregarFrame(new FrameInfo(494,1038,28,38), 50);
		caminandoI.agregarFrame(new FrameInfo(457,1040,27,37), 50);
		caminandoI.agregarFrame(new FrameInfo(422,1036,28,40), 50);
		caminandoI.agregarFrame(new FrameInfo(384,1037,27,38), 50);
		caminandoI.agregarFrame(new FrameInfo(347,1036,28,37), 50);
		caminandoI.agregarFrame(new FrameInfo(309,1035,27,37), 50);
		caminandoI.agregarFrame(new FrameInfo(273,1033,27,40), 50);
		caminandoI.agregarFrame(new FrameInfo(235,1034,27,38), 50);
		
		//Goku girando el baculo hacia la derecha
		Animacion baculoGiraD = new Animacion(spriteGoku);
		baculoGiraD.agregarFrame(new FrameInfo(5,150,28,37), 50);
		baculoGiraD.agregarFrame(new FrameInfo(45,151,30,37), 50);
		baculoGiraD.agregarFrame(new FrameInfo(86,151,31,39), 50);
		baculoGiraD.agregarFrame(new FrameInfo(127,152,35,39),50);
		baculoGiraD.agregarFrame(new FrameInfo(172,152,35,36), 50);
		baculoGiraD.agregarFrame(new FrameInfo(125,153,35,38), 50);
		baculoGiraD.agregarFrame(new FrameInfo(257,151,27,37), 50);
		baculoGiraD.agregarFrame(new FrameInfo(293,150,28,37), 50);
		
		//Goku puyando con el baculo hacia la derecha
		Animacion baculoPuyaD = new Animacion(spriteGoku);
		baculoPuyaD.agregarFrame(new FrameInfo(17,254,32,33), 100);
		baculoPuyaD.agregarFrame(new FrameInfo(58,255,36,33), 100);
		baculoPuyaD.agregarFrame(new FrameInfo(102,251,72,37), 100);
		baculoPuyaD.agregarFrame(new FrameInfo(181,252,70,36), 100);
		
		//Goku puyando con el baculo hacia la izquierda
		Animacion baculoPuyaI = new Animacion(spriteGoku);
		baculoPuyaI.agregarFrame(new FrameInfo(481,994,32,33), 100);
		baculoPuyaI.agregarFrame(new FrameInfo(436,995,36,33), 100);
		baculoPuyaI.agregarFrame(new FrameInfo(356,991,72,37), 100);
		baculoPuyaI.agregarFrame(new FrameInfo(279,992,70,36), 100);
		
		//Goku girando el baculo hacia la izquierda
		Animacion baculoGiraI = new Animacion(spriteGoku);
		baculoGiraI.agregarFrame(new FrameInfo(497,890,28,37), 50);
		baculoGiraI.agregarFrame(new FrameInfo(455,891,30,36), 50);
		baculoGiraI.agregarFrame(new FrameInfo(413,891,31,39), 50);
		baculoGiraI.agregarFrame(new FrameInfo(368,892,35,39), 50);
		baculoGiraI.agregarFrame(new FrameInfo(323,892,35,36), 50);
		baculoGiraI.agregarFrame(new FrameInfo(280,892,35,39), 50);
		baculoGiraI.agregarFrame(new FrameInfo(246,891,27,37), 50);
		baculoGiraI.agregarFrame(new FrameInfo(209,890,28,37), 50);
		
		//Goku tirando trompon hacia la derecha
		Animacion tromponD = new Animacion(spriteGoku);
		tromponD.agregarFrame(new FrameInfo(5,56,27,35), 50);
		tromponD.agregarFrame(new FrameInfo(42,55,34,36), 50);
		tromponD.agregarFrame(new FrameInfo(84,56,33,35), 50);
		tromponD.agregarFrame(new FrameInfo(125,55,34,36), 50);
		tromponD.agregarFrame(new FrameInfo(165,55,33,36), 50);
		tromponD.agregarFrame(new FrameInfo(206,55,29,36), 50);
		tromponD.agregarFrame(new FrameInfo(243,53,30,36), 50);
		tromponD.agregarFrame(new FrameInfo(282,52,29,37), 50);
		tromponD.agregarFrame(new FrameInfo(320,53,28,37), 50);
		tromponD.agregarFrame(new FrameInfo(356,55,42,35), 50);
				
		//Goku tirando trompon hacia la izquierda
		Animacion tromponI = new Animacion(spriteGoku);
		tromponI.agregarFrame(new FrameInfo(498,795,27,36), 50);
		tromponI.agregarFrame(new FrameInfo(454,795,34,36), 50);
		tromponI.agregarFrame(new FrameInfo(413,795,33,36), 50);
		tromponI.agregarFrame(new FrameInfo(371,795,34,36), 50);
		tromponI.agregarFrame(new FrameInfo(332,795,33,36), 50);
		tromponI.agregarFrame(new FrameInfo(295,795,29,36), 50);
		tromponI.agregarFrame(new FrameInfo(257,793,30,36), 50);
		tromponI.agregarFrame(new FrameInfo(219,792,29,37), 50);
		tromponI.agregarFrame(new FrameInfo(182,792,28,38), 50);
		tromponI.agregarFrame(new FrameInfo(132,795,42,35), 50);
				
		//Goku tira patada derecha
		Animacion patadaD = new Animacion(spriteGoku);
		patadaD.agregarFrame(new FrameInfo(12,482,27,37), 50);
		patadaD.agregarFrame(new FrameInfo(45,479,30,39), 50);
		patadaD.agregarFrame(new FrameInfo(86,476,45,42), 50);
		patadaD.agregarFrame(new FrameInfo(137,477,38,41), 50);
				
		//Goku tira patada derecha
		Animacion patadaI = new Animacion(spriteGoku);
		patadaI.agregarFrame(new FrameInfo(491,1222,27,37), 50);
		patadaI.agregarFrame(new FrameInfo(455,1219,30,39), 50);
		patadaI.agregarFrame(new FrameInfo(399,1216,45,42), 50);
		patadaI.agregarFrame(new FrameInfo(355,1217,38,41), 50);
				
		//Se crea el array con las animaciones y se crea el personaje goku
		ArrayList<Animacion> animaciones = new ArrayList<Animacion>();
		animaciones.add(explosion);
		animaciones.add(paradoD);
		animaciones.add(paradoI);
		animaciones.add(caminandoD);
		animaciones.add(caminandoI);
		animaciones.add(baculoGiraD);
		animaciones.add(baculoPuyaD);
		animaciones.add(baculoPuyaI);
		animaciones.add(baculoGiraI);
		animaciones.add(tromponD);
		animaciones.add(tromponI);
		animaciones.add(patadaD);
		animaciones.add(patadaI);
		Jugador goku = new Jugador(animaciones);
		goku.setIndiceAnimacion(1);
		
		Animacion foto = new Animacion(spriteGoku);
		foto.agregarFrame(new FrameInfo(75,680,30,30), 1000);
		goku.setAnimacionFoto(foto);
		return goku;
		
	}
	
	private Animacion getExplosion(){
		//Se prepara la animacion EXPLOSION
		Animacion explosion = new Animacion(spriteExplosion);
		explosion.agregarFrame(new FrameInfo(14,17,36,33), 25);
		explosion.agregarFrame(new FrameInfo(76,15,41,38), 25);
		explosion.agregarFrame(new FrameInfo(137,14,46,41), 25);
		explosion.agregarFrame(new FrameInfo(200,13,49,44), 25);
		explosion.agregarFrame(new FrameInfo(266,13,52,45), 25);
		//*******************************************************
		explosion.agregarFrame(new FrameInfo(6,76,54,47), 25);
		explosion.agregarFrame(new FrameInfo(70,76,55,48), 25);
		explosion.agregarFrame(new FrameInfo(133,76,56,48), 25);
		explosion.agregarFrame(new FrameInfo(197,75,57,50), 25);
		explosion.agregarFrame(new FrameInfo(260,75,58,50), 25);
		//*******************************************************
		explosion.agregarFrame(new FrameInfo(4,139,58,50), 25);
		explosion.agregarFrame(new FrameInfo(68,139,58,50), 25);
		explosion.agregarFrame(new FrameInfo(131,139,59,50), 25);
		explosion.agregarFrame(new FrameInfo(195,139,59,50), 25);
		explosion.agregarFrame(new FrameInfo(259,139,59,50), 25);
		//*******************************************************
		explosion.agregarFrame(new FrameInfo(4,204,58,48), 50);
		explosion.agregarFrame(new FrameInfo(68,204,58,48), 50);
		explosion.agregarFrame(new FrameInfo(132,204,58,48), 50);
		explosion.agregarFrame(new FrameInfo(196,205,58,47), 50);
		explosion.agregarFrame(new FrameInfo(260,205,58,47), 50);
		//*******************************************************
		explosion.agregarFrame(new FrameInfo(5,269,57,46), 65);
		explosion.agregarFrame(new FrameInfo(70,271,54,45), 75);
		explosion.agregarFrame(new FrameInfo(138,271,50,38), 85);
		explosion.agregarFrame(new FrameInfo(205,272,45,34), 95);
		explosion.agregarFrame(new FrameInfo(289,279,16,13), 110);
		return explosion;
	}

}
