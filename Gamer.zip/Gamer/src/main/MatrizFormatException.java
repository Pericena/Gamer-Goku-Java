package main;


public class MatrizFormatException extends Exception{
    
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MatrizFormatException(String e){
        super(e);
    }

}
