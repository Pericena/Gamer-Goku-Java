package main;

public class FrameInfo {
	
	int x,y,ancho,alto;
	
	public FrameInfo(int x,int y,int ancho, int alto){
		this.x = x;
		this.y = y;
		this.ancho = ancho;
		this.alto = alto;
	}

}
