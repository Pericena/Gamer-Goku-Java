package Enemigos;

import java.util.ArrayList;

import main.Animacion;

public class Fuego extends Enemigo{

	public Fuego(ArrayList<Animacion> animaciones) {
		super(animaciones);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void atacar() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void moverseDerecha() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void moverseIzquierda() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void detenerse() throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void morir() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void generarComportamiento() throws Exception {
		// TODO Auto-generated method stub
		
	}	
	
	
}
